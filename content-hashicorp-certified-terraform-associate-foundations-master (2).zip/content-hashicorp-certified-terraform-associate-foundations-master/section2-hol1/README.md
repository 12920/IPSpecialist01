## These files are for use only with Hands-on lab in the Terraform Cert Prep course on ACG
## No guarantees are provided for it's working outside of the mentioned lab.


