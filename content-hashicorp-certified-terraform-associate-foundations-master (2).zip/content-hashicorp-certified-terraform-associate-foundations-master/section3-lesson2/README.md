#This example uses null resources which implements the standard resource lifecylce in Terraform,
#but performs no further actions. 
#This code is for demonstrating Terraform Provisioners
